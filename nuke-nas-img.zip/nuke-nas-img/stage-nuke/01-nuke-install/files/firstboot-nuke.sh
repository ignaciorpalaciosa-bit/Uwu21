#!/bin/bash
# Corre UNA sola vez, en el primer arranque real de la Raspberry Pi
# (no durante el build). Genera una clave de sesión única para este
# dispositivo específico, en vez de compartir la misma para todas las
# imágenes grabadas desde este .img.
set -e

SECRET_FILE="/etc/nuke-nas/secret.env"

if [ ! -f "$SECRET_FILE" ]; then
  echo "NUKE_SECRET_KEY=$(head -c32 /dev/urandom | xxd -p | tr -d '\n')" > "$SECRET_FILE"
  chmod 600 "$SECRET_FILE"
fi

# Esto solo corre una vez: se desactiva a sí mismo al terminar
systemctl disable nuke-firstboot.service
