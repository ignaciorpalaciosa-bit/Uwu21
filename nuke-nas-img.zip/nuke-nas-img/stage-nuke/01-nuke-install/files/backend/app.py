#!/usr/bin/env python3
"""
Ñuke NAS - Panel de control
Backend liviano en Flask, pensado para correr bien en Raspberry Pi 3 (1GB RAM).
"""

import os
import re
import json
import shutil
import subprocess
import pwd
import grp
from datetime import datetime
from functools import wraps

from flask import Flask, jsonify, request, session, send_from_directory

app = Flask(__name__, static_folder="../frontend", static_url_path="")
app.secret_key = os.environ.get("NUKE_SECRET_KEY", os.urandom(24).hex())

CONFIG_PATH = "/etc/nuke-nas/config.json"
SHARES_BASE = "/srv/nuke"  # donde viven las carpetas compartidas
SMB_CONF = "/etc/samba/smb.conf"
EXPORTS_FILE = "/etc/exports"

os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
os.makedirs(SHARES_BASE, exist_ok=True)


# ---------------------------------------------------------------------------
# Config y utilidades
# ---------------------------------------------------------------------------

def load_config():
    if not os.path.exists(CONFIG_PATH):
        default = {
            "hostname": "nuke",
            "admin_user": "admin",
            "admin_password_hash": None,  # se define en el primer arranque
            "shares": [],  # [{"name": str, "path": str, "smb": bool, "nfs": bool, "public": bool}]
            "setup_complete": False,
        }
        save_config(default)
        return default
    with open(CONFIG_PATH) as f:
        return json.load(f)


def save_config(cfg):
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)


def run(cmd, check=True):
    """Ejecuta un comando de sistema y devuelve stdout. Usa list args, nunca shell=True con input de usuario."""
    result = subprocess.run(cmd, capture_output=True, text=True)
    if check and result.returncode != 0:
        raise RuntimeError(f"Comando falló ({' '.join(cmd)}): {result.stderr.strip()}")
    return result.stdout.strip()


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("logged_in"):
            return jsonify({"error": "No autenticado"}), 401
        return f(*args, **kwargs)
    return wrapper


SAFE_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,32}$")


def is_safe_name(name):
    return bool(SAFE_NAME_RE.match(name or ""))


# ---------------------------------------------------------------------------
# Autenticación
# ---------------------------------------------------------------------------

@app.route("/api/setup", methods=["POST"])
def setup():
    """Primer arranque: define usuario admin y contraseña del sistema Linux."""
    cfg = load_config()
    if cfg.get("setup_complete"):
        return jsonify({"error": "Ya configurado"}), 400

    data = request.get_json(force=True)
    username = data.get("username", "").strip()
    password = data.get("password", "")

    if not is_safe_name(username):
        return jsonify({"error": "Usuario inválido (solo letras, números, - y _)"}), 400
    if len(password) < 8:
        return jsonify({"error": "La contraseña debe tener al menos 8 caracteres"}), 400

    # Crear usuario del sistema si no existe (será dueño de los archivos compartidos)
    try:
        pwd.getpwnam(username)
    except KeyError:
        run(["useradd", "-m", "-s", "/usr/sbin/nologin", username])

    # Set password via chpasswd (stdin, evita exponer en argv/logs)
    proc = subprocess.run(
        ["chpasswd"], input=f"{username}:{password}", text=True, capture_output=True
    )
    if proc.returncode != 0:
        return jsonify({"error": "No se pudo establecer la contraseña"}), 500

    # Agregar como usuario Samba también
    proc = subprocess.run(
        ["smbpasswd", "-a", "-s", username],
        input=f"{password}\n{password}\n",
        text=True,
        capture_output=True,
    )

    cfg["admin_user"] = username
    cfg["setup_complete"] = True
    save_config(cfg)

    session["logged_in"] = True
    session["user"] = username
    return jsonify({"ok": True})


@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json(force=True)
    username = data.get("username", "")
    password = data.get("password", "")

    cfg = load_config()
    if not cfg.get("setup_complete"):
        return jsonify({"error": "Sistema no configurado", "needs_setup": True}), 400

    # Autentica contra el usuario del sistema usando 'su' con timeout, sin exponer password en argv
    try:
        proc = subprocess.run(
            ["python3", "-c",
             "import spwd,crypt,sys;"
             "u=sys.argv[1];p=sys.argv[2];"
             "e=spwd.getspnam(u).sp_pwdp;"
             "sys.exit(0 if crypt.crypt(p,e)==e else 1)",
             username, password],
            capture_output=True, timeout=5
        )
        ok = proc.returncode == 0
    except Exception:
        ok = False

    if not ok or username != cfg.get("admin_user"):
        return jsonify({"error": "Usuario o contraseña incorrectos"}), 401

    session["logged_in"] = True
    session["user"] = username
    return jsonify({"ok": True})


@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/api/status/setup", methods=["GET"])
def setup_status():
    cfg = load_config()
    return jsonify({"setup_complete": cfg.get("setup_complete", False)})


# ---------------------------------------------------------------------------
# Estado del sistema
# ---------------------------------------------------------------------------

@app.route("/api/system/stats", methods=["GET"])
@login_required
def system_stats():
    stats = {}

    # RAM
    try:
        with open("/proc/meminfo") as f:
            mem = {}
            for line in f:
                k, v = line.split(":")
                mem[k.strip()] = int(v.strip().split()[0])  # kB
        total = mem.get("MemTotal", 0)
        available = mem.get("MemAvailable", 0)
        stats["ram"] = {
            "total_mb": round(total / 1024, 1),
            "used_mb": round((total - available) / 1024, 1),
            "percent": round((total - available) / total * 100, 1) if total else 0,
        }
    except Exception:
        stats["ram"] = None

    # Temperatura (Raspberry Pi)
    try:
        temp_raw = run(["cat", "/sys/class/thermal/thermal_zone0/temp"], check=False)
        stats["temp_c"] = round(int(temp_raw) / 1000, 1) if temp_raw else None
    except Exception:
        stats["temp_c"] = None

    # Uptime
    try:
        with open("/proc/uptime") as f:
            uptime_s = float(f.read().split()[0])
        stats["uptime_hours"] = round(uptime_s / 3600, 1)
    except Exception:
        stats["uptime_hours"] = None

    # Carga del sistema
    try:
        load1, load5, load15 = os.getloadavg()
        stats["load"] = {"1m": round(load1, 2), "5m": round(load5, 2), "15m": round(load15, 2)}
    except Exception:
        stats["load"] = None

    # Discos
    stats["disks"] = get_disks()

    return jsonify(stats)


def get_disks():
    """Lista discos montados relevantes (excluye tmpfs, boot, etc)."""
    disks = []
    try:
        output = run(["df", "-B1", "--output=source,target,size,used,avail,pcent"], check=False)
        lines = output.splitlines()[1:]
        for line in lines:
            parts = line.split()
            if len(parts) < 6:
                continue
            source, target, size, used, avail, pcent = parts[:6]
            # Filtra sistemas de archivos virtuales y la partición de boot
            if not source.startswith("/dev/"):
                continue
            if target in ("/boot", "/boot/firmware") or target.startswith("/snap"):
                continue
            disks.append({
                "device": source,
                "mount": target,
                "size_gb": round(int(size) / (1024**3), 1),
                "used_gb": round(int(used) / (1024**3), 1),
                "avail_gb": round(int(avail) / (1024**3), 1),
                "percent": pcent.replace("%", ""),
            })
    except Exception:
        pass
    return disks


# ---------------------------------------------------------------------------
# Carpetas compartidas (shares)
# ---------------------------------------------------------------------------

@app.route("/api/shares", methods=["GET"])
@login_required
def list_shares():
    cfg = load_config()
    return jsonify(cfg.get("shares", []))


@app.route("/api/shares", methods=["POST"])
@login_required
def create_share():
    data = request.get_json(force=True)
    name = data.get("name", "").strip()
    smb = bool(data.get("smb", True))
    nfs = bool(data.get("nfs", False))
    public = bool(data.get("public", False))

    if not is_safe_name(name):
        return jsonify({"error": "Nombre inválido (solo letras, números, - y _)"}), 400

    cfg = load_config()
    if any(s["name"] == name for s in cfg["shares"]):
        return jsonify({"error": "Ya existe una carpeta con ese nombre"}), 400

    path = os.path.join(SHARES_BASE, name)
    os.makedirs(path, exist_ok=True)

    admin_user = cfg["admin_user"]
    try:
        uid = pwd.getpwnam(admin_user).pw_uid
        gid = pwd.getpwnam(admin_user).pw_gid
        os.chown(path, uid, gid)
    except Exception:
        pass
    os.chmod(path, 0o770 if not public else 0o777)

    share = {"name": name, "path": path, "smb": smb, "nfs": nfs, "public": public}
    cfg["shares"].append(share)
    save_config(cfg)

    regenerate_samba_config(cfg)
    if nfs:
        regenerate_nfs_exports(cfg)

    return jsonify(share)


@app.route("/api/shares/<name>", methods=["DELETE"])
@login_required
def delete_share(name):
    if not is_safe_name(name):
        return jsonify({"error": "Nombre inválido"}), 400

    cfg = load_config()
    share = next((s for s in cfg["shares"] if s["name"] == name), None)
    if not share:
        return jsonify({"error": "No encontrada"}), 404

    # Solo elimina la config, NO borra los archivos por seguridad
    cfg["shares"] = [s for s in cfg["shares"] if s["name"] != name]
    save_config(cfg)

    regenerate_samba_config(cfg)
    regenerate_nfs_exports(cfg)

    return jsonify({"ok": True, "note": "Los archivos NO fueron eliminados, solo se quitó de la config."})


def regenerate_samba_config(cfg):
    """Reescribe la sección de shares en smb.conf y recarga el servicio."""
    lines = [
        "# --- Generado por Ñuke NAS, no editar a mano bajo esta línea ---",
    ]
    for s in cfg["shares"]:
        if not s.get("smb"):
            continue
        lines.append(f"\n[{s['name']}]")
        lines.append(f"   path = {s['path']}")
        lines.append("   browseable = yes")
        lines.append("   read only = no")
        if s.get("public"):
            lines.append("   guest ok = yes")
        else:
            lines.append("   guest ok = no")
            lines.append(f"   valid users = {cfg['admin_user']}")

    marker = "# --- Generado por Ñuke NAS, no editar a mano bajo esta línea ---"
    try:
        if os.path.exists(SMB_CONF):
            with open(SMB_CONF) as f:
                content = f.read()
        else:
            content = "[global]\n   workgroup = WORKGROUP\n   server string = Ñuke NAS\n   security = user\n\n"

        base = content.split(marker)[0]
        with open(SMB_CONF, "w") as f:
            f.write(base + "\n".join(lines) + "\n")

        run(["systemctl", "reload", "smbd"], check=False)
    except Exception as e:
        print(f"Aviso: no se pudo regenerar smb.conf ({e}). ¿Corriendo sin permisos root?")


def regenerate_nfs_exports(cfg):
    marker = "# --- Generado por Ñuke NAS ---"
    lines = [marker]
    for s in cfg["shares"]:
        if not s.get("nfs"):
            continue
        opts = "rw,sync,no_subtree_check" + (",all_squash" if s.get("public") else "")
        lines.append(f"{s['path']} *({opts})")

    try:
        base = ""
        if os.path.exists(EXPORTS_FILE):
            with open(EXPORTS_FILE) as f:
                content = f.read()
            base = content.split(marker)[0]
        with open(EXPORTS_FILE, "w") as f:
            f.write(base + "\n".join(lines) + "\n")
        run(["exportfs", "-ra"], check=False)
    except Exception as e:
        print(f"Aviso: no se pudo regenerar /etc/exports ({e}).")


# ---------------------------------------------------------------------------
# Frontend estático
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/<path:path>")
def static_files(path):
    return send_from_directory(app.static_folder, path)


if __name__ == "__main__":
    # En producción esto corre detrás de systemd, escuchando solo en LAN
    app.run(host="0.0.0.0", port=8090, debug=False)
