#!/bin/bash -e
# Este script corre DENTRO del chroot durante el build de pi-gen.
# Instala Ñuke NAS en la imagen base.

install -d "${ROOTFS_DIR}/opt/nuke-nas"
install -d "${ROOTFS_DIR}/etc/nuke-nas"
install -d "${ROOTFS_DIR}/srv/nuke"

cp -r files/backend "${ROOTFS_DIR}/opt/nuke-nas/"
cp -r files/frontend "${ROOTFS_DIR}/opt/nuke-nas/"
install -m 644 files/nuke-nas.service "${ROOTFS_DIR}/etc/systemd/system/nuke-nas.service"
install -m 755 files/firstboot-nuke.sh "${ROOTFS_DIR}/opt/nuke-nas/firstboot-nuke.sh"

# Crea el entorno virtual de Python dentro del propio chroot (emulado por pi-gen vía binfmt)
on_chroot << EOF
python3 -m venv /opt/nuke-nas/venv
/opt/nuke-nas/venv/bin/pip install --quiet --upgrade pip
/opt/nuke-nas/venv/bin/pip install --quiet flask

systemctl enable smbd
systemctl enable nfs-kernel-server
systemctl enable nuke-nas
systemctl enable nuke-firstboot.service
EOF

# Servicio de primer arranque: genera la clave secreta y hostname únicos
# en el primer boot de CADA Pi (nunca la misma clave "de fábrica" para todos)
install -m 644 files/nuke-firstboot.service "${ROOTFS_DIR}/etc/systemd/system/nuke-firstboot.service"
