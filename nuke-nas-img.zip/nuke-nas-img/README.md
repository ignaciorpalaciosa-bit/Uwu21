# Ñuke NAS — imagen para Raspberry Pi

Este kit compila una imagen `.img` lista para grabar en la SD, con Ñuke NAS
ya instalado y configurado para arrancar solo. No necesitas Linux propio:
todo se compila gratis en los servidores de GitHub.

## Qué vas a hacer (resumen)

1. Crear un repositorio en GitHub y subir esta carpeta.
2. Activar GitHub Actions y correr el workflow de compilación.
3. Esperar ~1-2 horas.
4. Descargar el `.img.xz` resultante y grabarlo en la SD con Raspberry Pi Imager.

---

## Paso 1: Crear el repositorio en GitHub

1. Entra a [github.com](https://github.com) con tu cuenta y haz clic en el botón
   verde **"New"** (o el símbolo **+** arriba a la derecha → "New repository").
2. Ponle un nombre, por ejemplo `nuke-nas-img`.
3. Puedes dejarlo como **privado** (nadie más lo verá) — no es necesario que sea público.
4. **No** marques "Add a README file" (ya traemos uno). Clic en **"Create repository"**.
5. GitHub te va a mostrar una página con comandos. Vas a usar la opción de
   subir archivos existentes, así que sigue al paso 2.

## Paso 2: Subir esta carpeta al repositorio

La forma más simple sin usar la consola:

1. En la página de tu repo recién creado, busca el link **"uploading an existing file"**
   (aparece en el mensaje de bienvenida del repo vacío).
2. Arrastra **todo el contenido** de esta carpeta (`nuke-nas-img`) — incluyendo
   la carpeta oculta `.github` — a esa pantalla.
   - Importante: arrastra el *contenido* de la carpeta, no la carpeta misma.
   - Si tu navegador no te deja arrastrar la carpeta `.github` (por ser oculta),
     usa la alternativa de Git por consola más abajo.
3. Escribe un mensaje de commit como "Primera subida de Ñuke NAS" y confirma.

### Alternativa: subir por consola (más confiable para carpetas ocultas)

Si tienes Git instalado en tu PC (Windows, Mac o Linux, esto no requiere nada especial):

```bash
cd nuke-nas-img
git init
git add .
git commit -m "Primera subida de Ñuke NAS"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/nuke-nas-img.git
git push -u origin main
```

Reemplaza `TU-USUARIO` por tu nombre de usuario de GitHub. Te va a pedir
iniciar sesión (usa un [Personal Access Token](https://github.com/settings/tokens)
como contraseña si te lo pide, GitHub ya no acepta la contraseña normal por consola).

## Paso 3: Correr la compilación

1. En tu repositorio en GitHub, ve a la pestaña **"Actions"** (arriba).
2. Si es la primera vez, te va a pedir confirmar que quieres habilitar Actions — acepta.
3. Verás el workflow **"Compilar imagen Ñuke NAS"** en la lista de la izquierda. Haz clic en él.
4. Aparece un botón **"Run workflow"** (a la derecha) → clic → confirmar.
5. Se inicia el build. Puedes cerrar la pestaña, no necesitas quedarte mirando
   — te llega notificación por correo si algo falla.

**Tiempo esperado: 1 a 2 horas.** Compilar un sistema operativo completo desde
cero no es instantáneo, incluso en los servidores de GitHub.

## Paso 4: Descargar la imagen

1. Cuando el workflow termine con un ✅ verde, entra a esa ejecución (clic en ella).
2. Abajo, en la sección **"Artifacts"**, vas a ver `nuke-nas-img` — haz clic para descargarlo.
3. Es un `.zip` que contiene tu `nuke-nas-*.img.xz`. Descomprímelo.

## Paso 5: Grabar la imagen en la SD

1. Descarga [Raspberry Pi Imager](https://www.raspberrypi.com/software/) si no lo tienes.
2. Abre Raspberry Pi Imager → **"Choose OS"** → baja hasta **"Use custom"** →
   selecciona el archivo `.img.xz` que descargaste (no hace falta descomprimirlo más).
3. **"Choose Storage"** → selecciona tu tarjeta SD.
4. Haz clic en el ⚙️ (ajustes avanzados) antes de grabar, si quieres configurar
   tu WiFi desde ya (recomendado para no andar buscando un cable de red).
5. Graba, espera a que termine, y pon la SD en la Raspberry Pi.

## Primer arranque

1. Enciende la Pi conectada a tu red (WiFi configurado o cable de red).
2. Espera 1-2 minutos a que arranque por primera vez.
3. Busca su IP (desde tu router, con `ping nuke.local`, o con una app como
   "Fing" en el celular).
4. Entra desde el navegador a `http://IP-DE-TU-PI:8090` — vas a ver la
   pantalla de bienvenida de Ñuke donde creas tu usuario administrador.

## Importante: cambia la contraseña por defecto de SSH

Esta imagen viene con un usuario `nuke` / contraseña `nuke` habilitado **solo
para SSH** (para que puedas entrar a configurar WiFi o hacer mantenimiento).
**Cámbiala apenas entres por primera vez:**

```bash
ssh nuke@IP-DE-TU-PI
passwd
```

Esto es independiente del usuario que creas en el panel web de Ñuke (ese es
para SMB/NFS y para entrar al dashboard).

## ¿Y si algo falla en el build?

- Revisa la pestaña Actions → la ejecución fallida → los logs te dicen
  exactamente en qué paso falló.
- Los builds de pi-gen a veces fallan por timeouts de red al descargar
  paquetes de Debian — simplemente vuelve a correr el workflow ("Re-run jobs").
- Si el error es dentro de `stage-nuke`, probablemente sea algo que ajustar
  en `stage-nuke/01-nuke-install/01-run.sh` — con el log exacto te puedo ayudar
  a diagnosticarlo.

## Qué trae la imagen

Todo lo del panel Ñuke NAS que ya armamos (Samba, NFS, dashboard web liviano),
más:
- Hostname `nuke` (puedes acceder como `nuke.local` en la mayoría de redes)
- SSH activado
- Locale y teclado en español, zona horaria de Santiago de Chile
- Cada Pi genera su propia clave de sesión única al primer arranque (no
  comparten la misma clave todas las Pi grabadas desde este `.img`)
